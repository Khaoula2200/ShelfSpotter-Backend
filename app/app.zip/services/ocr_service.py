import os
os.environ["CUDA_VISIBLE_DEVICES"] = ""

import easyocr
import numpy as np
import cv2
from fastapi import UploadFile
import io
from PIL import Image

reader = easyocr.Reader(['en'], gpu=False)  # set gpu=True if you have CUDA

async def extract_text_from_image(image: UploadFile):
    image_bytes = await image.read()
    pil_image = Image.open(io.BytesIO(image_bytes)).convert("RGB")

    # Convert to numpy
    image_np = np.array(pil_image)

    # EasyOCR returns bounding boxes + text + confidence
    results = reader.readtext(image_np)

    lines = []
    for bbox, text, confidence in results:
        if confidence > 0.4 and len(text.strip()) > 3:
            lines.append(text.strip())

    print("Detected:", lines)
    return lines
