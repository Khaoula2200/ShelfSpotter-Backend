from fastapi import APIRouter, UploadFile, File
from fastapi.responses import JSONResponse
from app.services.ocr_service import extract_text_from_image

router = APIRouter()

@router.post("/")
async def scan_shelf(image: UploadFile = File(...)):
    # Call OCR service
    detected_titles = await extract_text_from_image(image)
    #print("OCR detected titles:", detected_titles)
    # Temporary top picks logic (can be improved later)
    top_picks = [{"title": title, "reason": "Recommended"} for title in detected_titles[:3]]

    return JSONResponse({
        "books": [{"title": title, "author": "", "confidence": 1.0} for title in detected_titles],
        "top_picks": top_picks
    })
